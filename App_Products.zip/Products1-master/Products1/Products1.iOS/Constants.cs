﻿namespace Products1.iOS
{
    public class Constants
    {
        public const string ConnectionString = "Endpoint=" +
            "sb://productsclass.servicebus.windows.net/;" +
            "SharedAccessKeyName=DefaultFullSharedAccessSignature;" +
            "SharedAccessKey=H8SNoyeqmGwTUpenZ2DArE9mLhHS3WrAFPL96wpwp6s=";
        public const string NotificationHubPath = "ProductsClass";
    }
}
