﻿namespace Products1.Views
{
    using Xamarin.Forms;

	public partial class NewCategoryView : ContentPage
    {
        public NewCategoryView()
        {
            InitializeComponent();
        }
    }
}
