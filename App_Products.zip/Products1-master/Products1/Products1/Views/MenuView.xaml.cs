﻿namespace Products1.Views
{
    using Xamarin.Forms;

    public partial class MenuView : ContentPage
    {
        public MenuView()
        {
            InitializeComponent();
        }
    }
}
