﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Products1.Views
{
    public partial class LoginView : ContentPage
    {
        public LoginView()
        {
            InitializeComponent();
        }
    }
}
