﻿namespace Products1.Views
{
    using Xamarin.Forms;

	public partial class EditCategoryView : ContentPage
    {
        public EditCategoryView()
        {
            InitializeComponent();
        }
    }
}
