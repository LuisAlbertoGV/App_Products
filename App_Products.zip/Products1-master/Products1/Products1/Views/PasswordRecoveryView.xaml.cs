﻿namespace Products1.Views
{
    using Xamarin.Forms;

    public partial class PasswordRecoveryView : ContentPage
    {
        public PasswordRecoveryView()
        {
            InitializeComponent();
        }
    }
}
