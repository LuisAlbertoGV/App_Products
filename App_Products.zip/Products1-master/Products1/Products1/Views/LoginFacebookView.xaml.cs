﻿namespace Products1.Views
{
    using Xamarin.Forms;

    public partial class LoginFacebookView : ContentPage
    {
        public LoginFacebookView()
        {
            InitializeComponent();
        }
    }
}
