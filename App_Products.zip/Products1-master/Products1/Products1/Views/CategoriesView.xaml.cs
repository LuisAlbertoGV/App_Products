﻿namespace Products1.Views
{
    using Xamarin.Forms;

    public partial class CategoriesView : ContentPage
    {
        public CategoriesView()
        {
            InitializeComponent();
        }
    }
}
